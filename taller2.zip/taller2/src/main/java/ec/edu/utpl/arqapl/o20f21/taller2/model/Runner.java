package ec.edu.utpl.arqapl.o20f21.taller2.model;

public class Runner {
    public static void main(String[] args) {


        producto producto1 = new producto("desorante","20",2);
        System.out.println("producto");
    }


}
